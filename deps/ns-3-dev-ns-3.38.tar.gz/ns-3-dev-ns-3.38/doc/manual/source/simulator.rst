.. only:: html or latex

Simulator
=========

This chapter explains some of the core ns-3 simulator concepts.

.. toctree::
   :maxdepth: 2

   events
   callbacks
   object-model
   attributes
   object-names
   realtime


